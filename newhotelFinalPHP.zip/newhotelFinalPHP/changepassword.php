<?php
  require "reservation/connect.php";

include('db.php');

$currentpassword=$_POST['currentpassword'];
$newpassword=$_POST['newpassword'];

mysqli_query($link,"UPDATE user SET password='$newpassword' WHERE password='$currentpassword'");
header("location: customerdashboard.php");
?>