<?php
	require "reservation/connect.php";
	include('db.php');
    require("twilio-php-master/Twilio/autoload.php");
    use Twilio\Rest\Client;

    $message = $_POST['message'];

    $account_sid = 'AC134f665874f96085111236907c042dab';
    $auth_token = '63287a4f816b09199cb7707d5064dc94';

    // A Twilio number you own with SMS capabilities
    $twilio_number = "+16479367608";

    $client = new Client($account_sid, $auth_token);

    $message = $client->messages
                  ->create("+14168280780", // to
                           array("from" => "+15878000728", "body" => $message)
                  );

	$name = $_POST['name'];
	$email = $_POST['email'];	
	$subject = $_POST['subject'];
	
	mysqli_query($link,"INSERT INTO message (name, email, subject, message) VALUES ('$name','$email','$subject','$message')");
	//header("location: sending.php");

	  
?>