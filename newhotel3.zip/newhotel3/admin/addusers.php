<script type="text/javascript">
function validateForm()
{
var a=document.forms["adduser"]["username"].value;
if (a==null || a=="")
  {
  alert("Please enter user name.");
  return false;
  }
var b=document.forms["adduser"]["password"].value;
if (b==null || b=="")
  {
  alert("Please enter password.");
  return false;
  }
 var c=document.forms["adduser"]["position"].value;
if (c==null || c=="")
  {
  alert("Please enter position.");
  return false;
  }
}
</script>
<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>
<!--sa input that accept number only-->
<SCRIPT language=Javascript>
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      //-->
   </SCRIPT>

<form action="user.php" method="post" enctype="multipart/form-data" name="adduser" onsubmit="return validateForm()">
 User Name<br />
  <input name="username1" type="text" class="ed" id="username"/><br />
 Password<br />
    <input name="password1" type="text" id="password" class="ed"/><br />
 Position<br />
    <input name="position1" type="text" id="position" class="ed"/><br />
    <input type="submit" name="Submit" value="save" id="button1" />
</form>